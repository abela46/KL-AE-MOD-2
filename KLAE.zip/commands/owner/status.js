const db = require("quick.db")
const discord = require("discord.js")

module.exports = {
  name: "status",
  description: "Change the bot status",
  usage: "status <here>",
  category: "owner",
  ownerOnly: true,
  run: async (client, message, args) => {
    
  
    //ARGUMENT
    if(!args.length) {
      return message.channel.send("<a:wrong_2:835736402573787177> Please give status message <a:wrong_2:835736402573787177>")
    }
    
 db.set(`status`, args.join(" "))
 client.user.setActivity(args.join(" ")); 
 message.channel.send("<a:tick:826693239054139423>  Updated the bot status <a:tick:826693239054139423>" + "`" + args.join(" ") + "`")

    
  }
}