const SnakeGame = require('snakecord');
const Discord = require("discord.js");
const client = new Discord.Client();
const snakeGame = new SnakeGame({
    title: 'Snake Game',
    color: "GREEN",
    timestamp: true,
    gameOverTitle: "<a:tada_animated:816209795509518376> Game Over <a:tada_animated:816209795509518376> "
});

module.exports = {
	name: "snake",
	category: "fun",
	run: async(client, message, args) => {
		snakeGame.newGame(message)
	}
}